from rest_framework import serializers
from book.models import Student,Genre,Language,Book,Borrower
from django.core.exceptions import ValidationError
class Studentserializer(serializers.ModelSerializer):
      class Meta:
            model=Student
            fields='__all__'
      '''
      def   validate_password(self,password):
            special_characters = "[~\!@#\$%\^&\*\(\)_\+{}\":;'\[\]]"
            if  not any(char.isdigit() for char in password):
                  raise ValidationError("password has no numeric")
            elif not any(char.isalpha() for char in password):
                  raise ValidationError("Password has no alpha character")
            elif not any(char in special_characters for char in password):
                  raise ValidationError("Password has no special character")
            elif len(password)<6:
                  raise ValidationError("Password has not enough length") 
            else:
                  return password
      def   validate(self,data):
            if data['roll_no']==data['name'] or data['roll_no']==data['branch'] or data['roll_no']==data['contact_no']:
              raise serializers.ValidationError(" roll_no and another field should not be same")
            else:
              return data
      '''
class Genreserializer(serializers.ModelSerializer):
      class Meta:
            model=Genre
            fields='__all__'
class Lanserializer(serializers.ModelSerializer):
      class Meta:
            model=Language
            fields='__all__'
class Bookserializer(serializers.ModelSerializer):
      class Meta:
            model=Book
            fields='__all__'
class Bookupdateserializer(serializers.ModelSerializer):
      class Meta:
            model=Book
            exclude=('total_copies','available_copies',)
class Borrowerserializer(serializers.ModelSerializer):
      class Meta:
            model=Borrower
            fields='__all__'
