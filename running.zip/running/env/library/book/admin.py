from django.contrib import admin
from django.contrib.admin import AdminSite
from book.models import Genre,Language,Book,Student,Borrower
import datetime
# Register your models here.
class StudentAdmin(admin.ModelAdmin):
      model = Student
      field="__all__"
      #readonly_fields = ['total_books_due']
      search_fields = ("roll_no__exact", )
      def has_delete_permission(self, request, obj=None):
          return obj is None or obj.total_books_due==0
class BorrowerAdmin(admin.ModelAdmin):
      model=Borrower
      search_fields = ['student__roll_no__exact','book__book_id',]
          
class BookAdmin(admin.ModelAdmin):
      search_fields = ['book_id','title','genre__name__exact','language__name__exact',]
      list_filter=['title',]

admin.site.register(Genre)
admin.site.register(Language)
admin.site.register(Book,BookAdmin)
admin.site.register(Student,StudentAdmin)
admin.site.register(Borrower,BorrowerAdmin)
