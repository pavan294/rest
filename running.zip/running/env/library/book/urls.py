"""library URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from . import views
from django.urls import path
from book.views import StudentViewSet,StudentListView,bookapi,StudentLIST,StudentDETAIL
Student_list = StudentViewSet.as_view({
    'get': 'list',
    'post': 'create'
})
Student_detail =StudentViewSet.as_view({
    'get': 'retrieve',
})
Student_update =StudentViewSet.as_view({
    'get': 'retrieve',
    'put': 'update',
    
})
Student_partial_update =StudentViewSet.as_view({
    'get': 'retrieve',
    'patch': 'partial_update',
    
})
Student_delete =StudentViewSet.as_view({
    'get': 'retrieve',
    'delete': 'destroy',    
})
urlpatterns = [
    path('logout',views.logout,name="logout"),
    path('borrowersearchform',views.borrowersearchform,name="borrowersearchform"),
    path('borrowersearch',views.borrowersearch,name="borrowersearch"),
    path('search1',views.search1,name="search1"),
    path('home',views.home,name="home"),
    path('basepage',views.basepage,name="basepage"),
    path('student',views.student,name="student"),
    path('studentdashboard',views.studentdashboard,name="studentdashboard"),
    path('adduserform',views.adduserform,name="adduserform"),
    path('adduser',views.adduser,name="adduser"),
    path('studentList',views.studentList,name="studentList"),
    path('studentDetailForm',views.studentDetailForm,name="studentDetailForm"),
    path('studentDetail',views.studentDetail,name="studentDetail"),
    path('genreaddform',views.genreaddform,name="genreaddform"),
    path('genreadd',views.genreadd,name="genreadd"),
    path('genrelist',views.genrelist,name="genrelist"),
    path('lanaddform',views.lanaddform,name="lanaddform"),
    path('lanadd',views.lanadd,name="lanadd"),
    path('lanlist',views.lanlist,name="lanlist"),
    path('addbookform',views.addbookform,name="addbookform"),
    path('addbook',views.addbook,name="addbook"),
    path('booklist',views.booklist,name="booklist"),
    path('bookdetailform1',views.bookdetailform1,name="bookdetailform1"),
    path('bookdetail1',views.bookdetail1,name="bookdetail1"),
    path('bookdetailform2',views.bookdetailform2,name="bookdetailform2"),
    path('bookdetail2',views.bookdetail2,name="bookdetail2"),
    path('addborrowerform',views.addborrowerform,name="addborrowerform"),
    path('addborrower',views.addborrower,name="addborrower"),
    path('updateborrowerform',views.updateborrowerform,name="updateborrowerform"),
    path('updateborrower',views.updateborrower,name="updateborrower"),
    path('borrowerlist',views.borrowerlist,name="borrowerlist"),
    path('borrowerdetailbyroll/<str:parameter>/', views.borrowerdetailbyroll, name='borrowerdetailbyroll'),
    path('studentDetailbyroll/<str:parameter>/', views.studentDetailbyroll, name='studentDetailbyroll'),
    path('studentdashboard1/<str:parameter>/', views.studentdashboard1, name='studentdashboard1'),
    path('lanlistp<str:parameter>/',views.lanlistp,name="lanlistp"),
    path('genrelistp<str:parameter>/',views.genrelistp,name="genrelistp"),
    path('<str:parameter>/bookdetailform1p/', views.bookdetailform1p, name='bookdetailform1p'),
    path('<str:parameter>/bookdetailform2p/', views.bookdetailform2p, name='bookdetailform2p'),
    path('<str:parameter>/bookdetail1p', views.bookdetail1p, name='bookdetail1p'),
    path('bookdetail2p<str:parameter>', views.bookdetail2p, name='bookdetail2p'),
    path('ubookeditform/<int:id>', views.ubookeditform, name='ubookeditform'),
    path('ubookedit/<int:id>', views.ubookedit, name='ubookedit'),
    path('ubookdelete/<int:id>', views.ubookdelete, name='ubookdelete'),
    path('ustudenteditform/<int:id>', views.ustudenteditform, name='ustudenteditform'),
    path('ustudentedit/<int:id>', views.ustudentedit, name='ustudentedit'),
    path('ustudentdelete/<int:id>', views.ustudentdelete, name='ustudentdelete'),
    path('ugenredelete/<int:id>', views.ugenredelete, name='ugenredelete'),
    path('ulandelete/<int:id>', views.ulandelete, name='ulandelete'),
    path('uborrowerdelete/<int:id>', views.uborrowerdelete, name='uborrowerdelete'),
    path('totalborrowers', views.totalborrowers, name='totalborrowers'),
    path('totalbookstaken', views.totalbookstaken, name='totalbookstaken'),
    path('Student_list/',Student_list, name='Student_list'),
    path('Student_detail/<int:pk>/',Student_detail, name='Student_detail'),
    path('Student_update/<int:pk>/',Student_update, name='Student_update'),
    path('Student_partial_update/<int:pk>/',Student_partial_update, name='Student_partial_update'),
    path('Student_delete/<int:pk>/',Student_delete, name='Student_delete'),
    path('StudentListView',views.StudentListView.as_view(), name='StudentListView'),
    path('Student',views.StudentView.as_view(), name='Student_view'),
    path('SearchListView',views.SearchListView.as_view(),name='SearchListView'),
    path('StudentLIST',views.StudentLIST.as_view(),name='StudentLIST'),
    path('StudentDETAIL/<int:pk>/',views.StudentDETAIL.as_view(),name='StudentDETAIL'),
    path('bookapi/<int:id>/',views.bookapi.as_view(),name='bookapi'),
    path('BOOKLIST/',views.BOOKLIST.as_view(),name='BOOKLIST'),
    path('BookView',views.BookView.as_view(),name='BookView'),
   ]
