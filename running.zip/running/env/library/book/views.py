from django.shortcuts import render,redirect
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.views.generic import ListView
#from book.forms import StudentForm,BookForm,BookUpdateForm
from book.models import Student,Genre,Language,Book,Borrower
from django.contrib import messages
from django.db.models import Sum,Count
from django.core.paginator import Paginator
import datetime
from rest_framework.decorators import api_view, renderer_classes
from rest_framework.renderers import JSONRenderer, TemplateHTMLRenderer
from rest_framework.response import Response
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from rest_framework import serializers
from .serializers  import  Studentserializer,Genreserializer,Lanserializer,Bookserializer,Bookupdateserializer
from rest_framework.parsers import JSONParser
from rest_framework import status
from rest_framework.views import APIView
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework import generics
from rest_framework import filters
def logout(request):
    response= redirect("/")
    response.delete_cookie('visits')
    return response
def student(request):
    return render(request,'studentlogin.html')
def studentdashboard(request):
    if request.method == "POST" :
        if Student.objects.filter(roll_no=request.POST['username'],password=request.POST['password']).exists():
           messages.warning(request,"student login successfull")
           return render(request,'studentdashboard.html',{'p':request.POST['username']})
        else:
           messages.warning(request,"enter valid credentials")
           return render(request,'studentlogin.html')
def basepage(request):
    return render(request,'basepage.html')
def studentdashboard1(request,parameter):
     return render(request,'studentdashboard.html',{'p':parameter}) 
@api_view(('GET','POST',))
@renderer_classes((TemplateHTMLRenderer, JSONRenderer))       
def adduserform(request):
    serializer=Studentserializer()
    return Response({'result': serializer}, template_name='adduserform.html')
    #return render(request,'adduserform.html',{'form':form})
@api_view(('POST','GET'))
def adduser(request):
    #data = JSONParser().parse(request)
    if request.method=="POST":
        serializer =Studentserializer(data=request.data)
        if  serializer.is_valid():
            if serializer.validated_data['total_books_due']==0:
                serializer.save()
                return Response( serializer.data)
            else:
                return Response("Failed as total_books_due not zero", status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    if  request.method=="GET":
        a=Student.objects.all()
        s=Studentserializer(a,many=True)
        return Response(s.data)
def studentList(request):
    result=Student.objects.all().order_by('roll_no')
    return render(request, 'studentlist.html', {'result':result})
class StudentListView(ListView):
      model=Student
      context_object_name='result'
      template_name='studentlistclass.html'
def studentDetailForm(request):
    return render(request,'studentdetailform.html')
def studentDetail(request):
    if request.method == "POST" :
        if Student.objects.filter(roll_no=request.POST['rollno']).exists():
            data=Student.objects.filter(roll_no=request.POST['rollno'])
            return render(request, 'studentlist.html', {'result':data})
        else:
            messages.warning(request,"student not found")
            return render(request, 'studentlist.html')
@api_view(('GET','POST',))
@renderer_classes((TemplateHTMLRenderer, JSONRenderer))    
def genreaddform(request):
    form=Genreserializer()
    return render(request,'genreaddform.html',{'form':form})
@api_view(('GET','POST',))
def genreadd(request):
    serializer =Genreserializer(data=request.data)
    if serializer.is_valid():
        if  Genre.objects.filter(name=serializer.validated_data['name']).exists():
            return Response({'serializer_failed': "genere already exists"}, status=status.HTTP_400_BAD_REQUEST)
        else:
            serializer.save()
            return Response({'serializer':serializer.data})
    else:
        return Response({'serializer':serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
@login_required
def genrelist(request):
    result= Genre.objects.annotate(no_books=Count('book')).values('id','name','no_books').order_by('name')
    p = Paginator(result,1)
    page_num=request.GET.get('page',1)
    p=p.page(page_num)
    return render(request, 'genrelist.html', {'p':p})
@api_view(('GET','POST',))
@renderer_classes((TemplateHTMLRenderer, JSONRenderer))    
def lanaddform(request):
    form=Lanserializer()
    return render(request,'lanaddform.html',{'form':form})
@api_view(('GET','POST',))
def lanadd(request):
    serializer =Lanserializer(data=request.data)
    if serializer.is_valid():
        if  Language.objects.filter(name=serializer.validated_data['name']).exists():
            return Response({'serializer_failed': "Language already exists"}, status=status.HTTP_400_BAD_REQUEST)
        else:
            serializer.save()
            return Response({'serializer':serializer.data})
    else:
        return Response({'serializer':serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
@login_required
def lanlist(request):
    #result=Language.objects.all().order_by('name')
    result= Language.objects.annotate(no_books=Count('book')).values('id','name','no_books').order_by('name')
    return render(request, 'lanlist.html', {'result':result})
@api_view(('GET','POST',))
@renderer_classes((TemplateHTMLRenderer, JSONRenderer))    
def addbookform(request):
    form=Bookserializer()
    return render(request,'addbookform.html',{'form':form})
@api_view(('GET','POST',))
def addbook(request):
    k=Bookserializer(data=request.data)
    if  k.is_valid():
        if  k.validated_data['total_copies']== k.validated_data['available_copies']:
            k.save()
            return Response(k.data)
        else:
            return Response({'serializer_failed': "toal and available not match"}, status=status.HTTP_400_BAD_REQUEST)
    else:
        return Response({'serializer_failed':k.errors}, status=status.HTTP_400_BAD_REQUEST)
@login_required(login_url='/home/pavan')
def booklist(request):
    #result=Book.objects.all().order_by('-title','author')
    result=Book.objects.annotate(Count('borrower__student__roll_no',distinct=True)).values('id','book_id','title','author','summary','version','genre__name','language__name','total_copies','available_copies','borrower__student__roll_no__count').order_by('-title','author')
    p = Paginator(result,5)
    page_num=request.GET.get('page',1)
    p=p.get_page(page_num)
    response=render(request, 'booklist.html', {'result':p})
    if request.COOKIES.get('visits'):
       value=int(request.COOKIES.get('visits'))
       response.set_cookie('visits',value+1)
    else:
       response.set_cookie('visits',value=1)
    return response
def bookdetailform1(request):
    return render(request,'bookdetailform1.html')
def bookdetailform2(request):
    return render(request,'bookdetailform2.html')
def bookdetail1(request):
    if request.method == "POST" :
        if Book.objects.filter(genre__name=request.POST['genre']).exists():
           data=Book.objects.filter(genre__name=request.POST['genre']).annotate(Count('borrower__student__roll_no',distinct=True)).values('id','book_id','title','author','summary','version','genre__name','language__name','total_copies','available_copies','borrower__student__roll_no__count').order_by('-title','author')
           return render(request, 'booklist.html', {'result':data})
        else:
           messages.success(request,"Books not found")
           return render(request, 'booklist.html')
def bookdetail2(request):
    if request.method == "POST" :
        if Book.objects.filter(language__name=request.POST['language']).exists():
           data=Book.objects.filter(language__name=request.POST['language']).annotate(Count('borrower__student__roll_no',distinct=True)).values('id','book_id','title','author','summary','version','genre__name','language__name','total_copies','available_copies','borrower__student__roll_no__count').order_by('-title','author')
           print(data.values())
           return render(request, 'booklist.html', {'result':data})
        else:
           messages.success(request,"Books not found")
           return render(request, 'booklist.html')
def addborrowerform(request):
    return render(request,'addborrowerform.html')
def addborrower(request):
    if request.method == "POST" :
        k=request.POST['book_id']
        p=request.POST['roll_no']
        if Book.objects.filter(book_id=k).exists() and Student.objects.filter(roll_no=p).exists():
            obj = Book.objects.get(book_id=k)
            s=Student.objects.get(roll_no=p)
            if Borrower.objects.filter(book__book_id=k,student__roll_no=p).exists():
               messages.success(request,"already book taken")
            elif s.total_books_due < 7:
                messages.success(request,"book has been issued, You can collect book from library")
                a = Borrower()
                a.student = s
                a.book = obj
                a.issue_date = datetime.datetime.now()
                if obj.available_copies -1>=1:
                    obj.available_copies = obj.available_copies - 1
                    obj.save()
                    s.total_books_due=s.total_books_due+1
                    s.save()
                    a.save()
                else:
                    messages.success(request,"No available books to issue")
            else:
                messages.success(request,"you have exceeded limit.")
        else:
            messages.success(request,"invalid student or book")
        return render(request, 'addborrowerform.html')    
def updateborrowerform(request):
    return render(request,'updateborrowerform.html')
def updateborrower(request):
    if request.method == "POST" :
        k=request.POST['book_id']
        p=request.POST['roll_no']
        if Book.objects.filter(book_id=k).exists() and Student.objects.filter(roll_no=p).exists() and Borrower.objects.filter(student__roll_no=p,book__book_id=k).exists():
            obj = Book.objects.get(book_id=k)
            s=Student.objects.get(roll_no=p)
            s.total_books_due=s.total_books_due-1
            obj.available_copies=obj.available_copies+1
            s.save()
            obj.save()
            Borrower.objects.get(student=s,book=obj).delete()
            messages.success(request,"book successfully return")
        else:
            messages.warning(request,"borrower does not exist")
        return render(request, 'updateborrowerform.html')
@login_required
def borrowerlist(request):
    k=Borrower.objects.all().order_by('issue_date')
    p = Paginator(k,5)
    page_num=request.GET.get('page',1)
    p=p.page(page_num)
    return render(request, 'borrowerlist.html',{'result':p})
def borrowerdetailbyroll(request,parameter):
    p=parameter
    if Student.objects.filter(roll_no=p).exists():
        if Borrower.objects.filter(student__roll_no=p).exists():
            a=Borrower.objects.filter(student__roll_no=p)
            result=a
            context={'result':result,'p':p,}
            return render(request, 'borrowerlistp.html',context)
        else:
            result="borrower not found"
            context={'result':result,'p':p,}
            return render(request, 'resultp.html',context)
    else:
        result="borrower not found as student invalid"
        return render(request, 'result1.html',{'result':result})
def studentDetailbyroll(request,parameter):
    if Student.objects.filter(roll_no=parameter).exists():
       data=Student.objects.get(roll_no=parameter)
       context={'i':data,'p':parameter,}
       return render(request, 'studentDetailp.html',context)
    else:
        data="student not found"
        context={'result':data,'p':parameter,}
        return render(request, 'resultp.html',context)
def genrelistp(request,parameter):
    result=Genre.objects.all()
    context={'result':result,'p':parameter}
    return render(request, 'genrelistp.html',context)
def lanlistp(request,parameter):
    result=Language.objects.all()
    context={'result':result,'p':parameter}
    return render(request, 'lanlistp.html',context)
def bookdetailform1p(request,parameter):
    return render(request,'bookdetailform1p.html',{'p':parameter})
def bookdetailform2p(request,parameter):
    return render(request,'bookdetailform2p.html',{'p':parameter})
def bookdetail1p(request,parameter):
    if request.method == "POST" :
        if Book.objects.filter(genre__name=request.POST['genre']).exists():
           data=Book.objects.filter(genre__name=request.POST['genre'])
           context={'result':data,'p':parameter,}
           return render(request, 'bookdetailp.html',context)
        else:
           data="Books not found"
           context={'result':data,'p':parameter,}
           return render(request, 'resultp.html',context)
def bookdetail2p(request,parameter):
    if request.method == "POST" :
        if Book.objects.filter(language__name=request.POST['language']).exists():
           data=Book.objects.filter(language__name=request.POST['language'])
           context={'result':data,'p':parameter,}
           return render(request, 'bookdetailp.html',context)
        else:
           data="Books not found"
           context={'result':data,'p':parameter,}
           return render(request, 'resultp.html',context)
def home(request):
    return render(request,'home.html')
@api_view(('GET','POST',))
@renderer_classes((TemplateHTMLRenderer, JSONRenderer))      
def ubookeditform(request,id):
    b=Book.objects.get(id=id)
    form=Bookupdateserializer(instance=b)
    context={'form':form,'id':id}
    return render(request,'ubookeditform.html',context)
@api_view(('GET','POST',))
def ubookedit(request,id):
    b=Book.objects.get(id=id)
    k=Bookupdateserializer(data=request.data,instance=b)
    if k.is_valid():
        k.save()
        return Response({'serializer':k.data})
    else:
        return Response({'serializer':k.errors}, status=status.HTTP_400_BAD_REQUEST)
def ubookdelete(request,id):
    b=Book.objects.get(id=id)
    b.delete()
    messages.success(request,"deleted successfully")
    p=Book.objects.annotate(Count('borrower__student__roll_no',distinct=True)).values('id','book_id','title','author','summary','version','genre__name','language__name','total_copies','available_copies','borrower__student__roll_no__count').order_by('-title','author')
    return render(request,'booklist.html',{'result':p})
@api_view(('GET','POST','DELETE'))
def ustudentedit(request,id):
    if request.method=="POST":
        b=Student.objects.get(id=id)
        serializer =Studentserializer(data=request.data,instance=b)
        if  serializer.is_valid():
            serializer.save()
            return Response({'serializer': serializer.data})
        else:
            return Response({'serializer':serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
    if request.method=="DELETE":
       s=Student.objects.get(id=id)
       s.delete()
       return Response(status=status.HTTP_204_NO_CONTENT)
def ustudentdelete(request,id):
    b=Student.objects.get(id=id)
    if b.total_books_due>=1:
       return JsonResponse('clear books',safe=False)
    else:
       if request.method == 'GET':
            b.delete()
            return JsonResponse('successfully deleted',safe=False)
@api_view(('GET','POST','PUT'))
@renderer_classes((TemplateHTMLRenderer, JSONRenderer))    
def ustudenteditform(request,id):
    p=Student.objects.get(id=id)
    serializer=Studentserializer(instance=p)
    return Response({'result': serializer,'id':id}, template_name='ustudenteditform.html')
def ugenredelete(request,id):
    b=Genre.objects.get(id=id)
    b.delete()
    messages.success(request,"deleted successfully")
    a=Genre.objects.annotate(no_books=Count('book')).values('id','name','no_books').order_by('name')
    return render(request,'genrelist.html',{'result':a})
def ulandelete(request,id):
    b=Language.objects.get(id=id)
    b.delete()
    messages.success(request,"deleted successfully")
    d=Language.objects.annotate(no_books=Count('book')).values('id','name','no_books').order_by('name')
    return render(request,'lanlist.html',{'result':d})
def uborrowerdelete(request,id):
    b=Borrower.objects.get(id=id)
    b.delete()
    s="deleted successfully"
    return render(request,'result.html',{'result':s})
def search1(request):
    if request.method=="POST":
        k=request.POST.get('get_value')
        if k=='roll_no':
            if request.method == "POST" :
                p=request.POST['value']
                if Student.objects.filter(roll_no=p).exists():
                    if Borrower.objects.filter(student__roll_no=p).exists():
                        a=Borrower.objects.filter(student__roll_no=p)
                        result=a
                        return render(request, 'borrowerlist.html',{'result':result})
                    else:
                        messages.error(request,"borrower not found")
                        return render(request, 'borrowerlist.html')
                else:
                    messages.success(request,"borrower not found as student invalid")
                    return render(request, 'borrowerlist.html')
        elif k=='book_id':
            if request.method == "POST" :
                p=request.POST['value']
                if Book.objects.filter(book_id=p).exists():
                    if Borrower.objects.filter(book__book_id=p).exists():
                        a=Borrower.objects.filter(book__book_id=p)
                        result=a
                        return render(request, 'borrowerlist.html',{'result':result})
                    else:
                        messages.error(request,"borrower not found")
                        return render(request, 'borrowerlist.html')
                else:
                    messages.error(request,"borrower not found as book invalid")
                    return render(request, 'borrowerlist.html')
@login_required                
def totalborrowers(request):
    p=Student.objects.filter(total_books_due__gte=1).count()
    k="total students who took books:"+str(p)
    messages.success(request,k)
    return render(request,'home.html')
@login_required
def totalbookstaken(request):
    z=Student.objects.all().aggregate(Sum('total_books_due'))
    messages.success(request,str(z))
    return render(request,'home.html')
def borrowersearchform(request):
    return render(request,'borrowersearchform.html')
def borrowersearch(request):
    if request.method == "POST" :
        p=request.POST['book_id']
        q=request.POST['roll_no']
        if Borrower.objects.filter(book__book_id=p,student__roll_no=q).exists():
            a=Borrower.objects.filter(book__book_id=p,student__roll_no=q)
            return render(request, 'borrowerlist.html',{'result':a})
        else:
            messages.error(request,"borrower not found")
            return render(request, 'borrowerlist.html')
class StudentViewSet(viewsets.ModelViewSet):
    serializer_class=Studentserializer
    queryset=Student.objects.all()
    lookup_field='pk'
    def list(self,request):
        a=Student.objects.all()
        s=Studentserializer(a,many=True)
        return Response(s.data,status=status.HTTP_201_CREATED)
    def create(self,request):
        s=Studentserializer(data=request.data)
        if s.is_valid():
            s.save()
            return Response(s.data,status=status.HTTP_201_CREATED)
        else:
            return Response(s.errors, status=status.HTTP_400_BAD_REQUEST)
    def retrieve(self,request,pk):
        a=Student.objects.get(id=pk)
        s=Studentserializer(a)
        return Response(s.data,status=status.HTTP_200_OK)
    def update(self,request,pk):
        a=Student.objects.get(id=pk)
        serializer=Studentserializer(a,request.data)
        if serializer.is_valid():
           serializer.save()
           return Response(serializer.data,status=status.HTTP_201_CREATED)
        else:
           return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    def partial_update(self,request,pk):
        a=Student.objects.get(id=pk)
        serializer=Studentserializer(a,request.data,partial=True)
        if serializer.is_valid():
           serializer.save()
           return Response(serializer.data,status=status.HTTP_201_CREATED)
        else:
           return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    def delete(self,request,pk):
        b=Student.objects.get(id=pk)
        b.delete()
        return Response(status=status.HTTP_404_NOT_FOUND)
class StudentLIST(APIView):
    serializer_class=Studentserializer
    queryset=Student.objects.all()
    lookup_field='pk'
    def get(self,request):
        a=Student.objects.all()
        s=Studentserializer(a,many=True)
        return Response(s.data,status=status.HTTP_201_CREATED)
    def post(self,request):
        s=Studentserializer(data=request.data)
        if s.is_valid():
            s.save()
            return Response(s.data,status=status.HTTP_201_CREATED)
        else:
            return Response(s.errors, status=status.HTTP_400_BAD_REQUEST)    
class StudentDETAIL(APIView):
    serializer_class=Studentserializer
    queryset=Student.objects.all()
    lookup_field='pk'
    def get(self,request,pk):
        a=Student.objects.get(id=pk)
        s=Studentserializer(a)
        return Response(s.data,status=status.HTTP_200_OK)
    def put(self,request,pk):
        a=Student.objects.get(id=pk)
        serializer=Studentserializer(a,request.data)
        if serializer.is_valid():
           serializer.save()
           return Response(serializer.data,status=status.HTTP_201_CREATED)
        else:
           return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    def patch(self,request,pk):
        a=Student.objects.get(id=pk)
        serializer=Studentserializer(a,request.data,partial=True)
        if serializer.is_valid():
           serializer.save()
           return Response(serializer.data,status=status.HTTP_201_CREATED)
        else:
           return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    def delete(self,request,pk):
        b=Student.objects.get(id=pk)
        b.delete()
        return Response(status=status.HTTP_404_NOT_FOUND)
class StudentView(APIView):
    def post(self, request):
        k=request.data['rollno']
        if  Student.objects.filter(roll_no=k).exists():
            serializer =Studentserializer(Student.objects.get(roll_no=k))
            return Response(serializer.data)    
        else:
            return Response("not found",status=status.HTTP_400_BAD_REQUEST)  
class BookView(APIView):
    def post(self, request):
        k=request.data['get_value']
        if k=='title':
            if Book.objects.filter(title=request.data['value']).exists():
                serializer=Bookserializer(Book.objects.filter(title=request.data['value']),many=True)
                return Response(serializer.data)    
            else:
                return Response("not found",status=status.HTTP_400_BAD_REQUEST) 
        elif k=='genre':
             if Book.objects.filter(genre__name=request.POST['value']).exists():
                serializer=Bookserializer(Book.objects.filter(genre__name=request.POST['value']),many=True)
                return Response(serializer.data)  
             else:
                return Response("not found",status=status.HTTP_400_BAD_REQUEST) 
        elif k=='language':
             if Book.objects.filter(language__name=request.POST['value']).exists():
                serializer=Bookserializer(Book.objects.filter(language__name=request.POST['value']),many=True)
                return Response(serializer.data)
             else:
                return Response("not found",status=status.HTTP_400_BAD_REQUEST)   
        elif k=='book_id':
             if Book.objects.filter(book_id=request.POST['value']).exists():
                serializer=Bookserializer(Book.objects.filter(book_id=request.POST['value']),many=True)
                return Response(serializer.data)
             else:
                return Response("not found",status=status.HTTP_400_BAD_REQUEST) 
    
class SearchListView(generics.ListAPIView):
    queryset =Student.objects.all()
    serializer_class =Studentserializer
    filter_backends = [filters.SearchFilter]
    search_fields = ['name','roll_no','branch']
class bookapi(generics.RetrieveUpdateDestroyAPIView):
    queryset = Book.objects.all()
    lookup_field='id'
    serializer_class =Bookserializer
    filter_backends = [filters.SearchFilter]
    search_fields = ['title']
class BOOKLIST(generics.ListAPIView):
    queryset =Book.objects.all()
    serializer_class=Bookserializer
    filter_backends = [filters.SearchFilter]
    search_fields = ['title','book_id','genre__name','language__name']
    def post(self,request):
        s=Bookserializer(data=request.data)
        if s.is_valid():
            s.save()
            return Response(s.data,status=status.HTTP_201_CREATED)
        else:
            return Response(s.errors, status=status.HTTP_400_BAD_REQUEST)   

