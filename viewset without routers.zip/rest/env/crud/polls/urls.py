from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .import views
from polls.views import EmployeeViewSet,EmployeeView,UserListView
employee_list = EmployeeViewSet.as_view({
    'get': 'list',
    'post': 'create'
})
employee_detail =EmployeeViewSet.as_view({
    'get': 'retrieve',
})
employee_update =EmployeeViewSet.as_view({
    'put': 'update',
    
})
employee_partial_update =EmployeeViewSet.as_view({
    'patch': 'partial_update',
    
})
employee_delete =EmployeeViewSet.as_view({
    'delete': 'destroy',    
})
employee_p =EmployeeViewSet.as_view({
    'get': 'yoga',   

})
urlpatterns = [
    path('',views.EmployeeView.as_view(), name='employee'),
    path('employee_list/',employee_list, name='employee_list'),
    path('employee_detail/<int:pk>/',employee_detail, name='employee_detail'),
    path('employee_update/<int:pk>/',employee_update , name='employee_update '),
    path('employee_partial_update/<int:pk>/',employee_partial_update, name='employee_partial_update '),
    path('employee_delete/<int:pk>/',employee_delete, name='employee_delete'),
    path('UserListView',views.UserListView.as_view(), name='UserListView'),
    path('employee',employee_p, name='employee_p'),
]
