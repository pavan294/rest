from django.contrib import admin
from polls.models import Employee
admin.site.register(Employee)
# Register your models here.
