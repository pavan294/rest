from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .import views
from polls.models import Employee
from polls.views import EmployeeList,EmployeeDetail,EmployeeGET
urlpatterns = [
    path('pavan/',views.EmployeeList.as_view(), name='employee'),
    path('employee_detail/<int:pk>/',EmployeeDetail.as_view(), name='employee_detail'),
    path('employee/<int:pk>/',EmployeeGET.as_view(), name='employee'),
]
