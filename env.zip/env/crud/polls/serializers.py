from django.test import TestCase

# Create your tests here.
# Create your tests here.
from rest_framework import serializers
from django.core.exceptions import ValidationError
from polls.models import Employee
class Employeeserializer(serializers.ModelSerializer):
      class Meta:
            model=Employee
            fields=('first_name','last_name')
      def validate_first_name(self,value):
          if len(value)>=6:
             raise serializers.ValidationError("length exceeded") 
          else:
             return value 
      def validate(self,data):
          if data['first_name']==data['last_name']:
             raise serializers.ValidationError("should not be same")
          else:
             return data
      def to_internal_value(self, data):
         print(data)
         return super().to_internal_value(data)