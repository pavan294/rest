'''
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
  
from polls.models import Employee
from polls.serializers import Employeeserializer
  
@csrf_exempt
def polls_list(request):
    """
    List all transformers, or create a new transformer
    """
    if request.method == 'GET':
        transformer =Employee.objects.all()
        serializer = Employeeserializer(transformer, many=True)
        return JsonResponse(serializer.data, safe=False)
  
    elif request.method == 'POST':
        data = JSONParser().parse(request)
        serializer =Employeeserializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data, status=201)
        return JsonResponse(serializer.errors, status=400)
  
@csrf_exempt
def polls_detail(request, pk):
    try:
        transformer = Employee.objects.get(pk=pk)
    except Transformer.DoesNotExist:
        return HttpResponse(status=404)
  
    if request.method == 'GET':
        serializer =Employeeserializer(transformer)
        return JsonResponse(serializer.data)
  
    elif request.method == 'PUT':
        data = JSONParser().parse(request)
        serializer = Employeeserializer(transformer, data=data)
  
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data)
        return JsonResponse(serializer.errors, status=400)
  
    elif request.method == 'DELETE':
        transformer.delete()
        return HttpResponse(status=204)
'''
import io
from django.shortcuts import render
from django.http import JsonResponse
from rest_framework import serializers
from .models import Employee
from .serializers  import  Employeeserializer
from rest_framework.views import APIView
from rest_framework import viewsets
from django.views.generic import CreateView
from rest_framework.response import Response
from rest_framework import status,filters
from rest_framework.views import APIView
from rest_framework.renderers import JSONRenderer,TemplateHTMLRenderer,BrowsableAPIRenderer,AdminRenderer
from rest_framework.parsers import JSONParser
from rest_framework import generics
from rest_framework.decorators import action
from rest_framework.authentication import SessionAuthentication, BasicAuthentication,TokenAuthentication
from rest_framework.permissions import IsAuthenticated,IsAdminUser
import django_filters
class EmployeeFilter(django_filters.FilterSet):
    last_name = django_filters.CharFilter(lookup_expr='iexact')
    #first_name = django_filters.CharFilter(lookup_expr='iexact')
    class Meta:
        model =Employee
        fields = ['first_name']
class EmployeeList(generics.ListAPIView):
    serializer_class=Employeeserializer
    queryset=Employee.objects.all()
    renderer_classes=[AdminRenderer]
    #filterset_fields = {'first_name':['exact', 'lte', 'gte'],}
    filterset_class = EmployeeFilter
    #filter_backends = [filters.SearchFilter]
    #search_fields = ['first_name','last_name']
    #authentication_classes = [BasicAuthentication]
    #permission_classes = [IsAdminUser]
    '''
    def get(self,request,format=None):
        a=Employee.objects.all()
        s=Employeeserializer(a,many=True)
        response=Response(s.data,status=status.HTTP_201_CREATED)
        #response.accepted_renderer =TemplateHTMLRenderer()
        #response.accepted_content_type = "application/json"
        return response
    '''
    def post(self,request):
        s= Employeeserializer(data=request.data,many=True)

        if s.is_valid():
            s.save()
            return Response(s.data,status=status.HTTP_201_CREATED)
        else:
            return Response(s.errors, status=status.HTTP_400_BAD_REQUEST)
class EmployeeGET(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = Employeeserializer
    queryset=Employee.objects.all()
class EmployeeDetail(APIView):
    serializer_class=Employeeserializer
    queryset=Employee.objects.all()
    lookup_field='pk'
    def get(self,request,pk):
        a=Employee.objects.get(id=pk)
        s=Employeeserializer(a)
        return Response(s.data,status=status.HTTP_200_OK)
    def put(self,request,pk):
        a=Employee.objects.get(id=pk)
        k=request.body
        print(k)
        stream = io.BytesIO(k)         
        data = JSONParser().parse(stream)
        serializer=Employeeserializer(a,data=data)
        if serializer.is_valid():
           serializer.save()
           return Response(serializer.data,status=status.HTTP_201_CREATED)
        else:
           return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    def patch(self,request,pk):
        a=Employee.objects.get(id=pk)
        print(request.body)
        serializer=Employeeserializer(a,request.data,partial=True)
        if serializer.is_valid():
           serializer.save()
           return Response(serializer.data,status=status.HTTP_201_CREATED)
        else:
           return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    def delete(self,request,pk):
        b=Employee.objects.get(id=pk)
        b.delete()
        return Response(status=status.HTTP_404_NOT_FOUND)