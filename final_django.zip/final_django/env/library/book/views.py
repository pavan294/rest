from django.shortcuts import render
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from book.forms import StudentForm,BookForm,BookUpdateForm
from book.models import Student,Genre,Language,Book,Borrower
from django.contrib import messages
from django.db.models import Sum,Count
from django.core.paginator import Paginator
import datetime
from django.contrib.auth.decorators import login_required
def student(request):
    return render(request,'studentlogin.html')
def studentdashboard(request):
    if request.method == "POST" :
        if Student.objects.filter(roll_no=request.POST['username'],password=request.POST['password']).exists():
           messages.warning(request,"student login successfull")
           return render(request,'studentdashboard.html',{'p':request.POST['username']})
        else:
           messages.warning(request,"enter valid credentials")
           return render(request,'studentlogin.html')
def basepage(request):
    return render(request,'basepage.html')
def studentdashboard1(request,parameter):
     return render(request,'studentdashboard.html',{'p':parameter})        
def adduserform(request):
    form=StudentForm()
    return render(request,'adduserform.html',{'form':form})
def adduser(request):
    if request.method == "POST":  
        k=StudentForm(data=request.POST)
        if Student.objects.filter(roll_no=k['roll_no'].value()).exists():
            messages.success(request,"student already exists")
            p=StudentForm()
            return render(request,'adduserform.html',{'form':p})
        else:
            p=StudentForm(request.POST)
            if p.is_valid():
             p.total_books_due=0
             p.save()
             messages.success(request,"student added")
            else:
             messages.success(request,"form not valid")
            return render(request,'adduserform.html',{'form':p})
def studentList(request):
    result=Student.objects.all().order_by('roll_no')
    return render(request, 'studentlist.html', {'result':result})
def studentDetailForm(request):
    return render(request,'studentdetailform.html')
def studentDetail(request):
    if request.method == "POST" :
        if Student.objects.filter(roll_no=request.POST['rollno']).exists():
            data=Student.objects.filter(roll_no=request.POST['rollno'])
            return render(request, 'studentlist.html', {'result':data})
        else:
            messages.warning(request,"student not found")
            return render(request, 'studentlist.html')
def genreaddform(request):
    return render(request,'genreaddform.html')
def genreadd(request):
    if request.method == "POST" :
        k=request.POST['name']
        if Genre.objects.filter(name=k).exists():
           messages.success(request,"genre already exists")
        else:
            p=Genre(name=k)
            p.save()
            messages.success(request,"genre added")
    return render(request, 'genreaddform.html')
@login_required
def genrelist(request):
    result= Genre.objects.annotate(no_books=Count('book')).values('id','name','no_books').order_by('name')
    p = Paginator(result,1)
    page_num=request.GET.get('page',1)
    p=p.page(page_num)
    return render(request, 'genrelist.html', {'p':p})
def lanaddform(request):
    return render(request,'lanaddform.html')
def lanadd(request):
    if request.method == "POST" :
        k=request.POST['name']
        if Language.objects.filter(name=k).exists():
           messages.success(request,"Language already exists")
        else:
            p=Language(name=k)
            p.save()
            messages.success(request,"Language added")
        return render(request, 'lanaddform.html')
@login_required
def lanlist(request):
    #result=Language.objects.all().order_by('name')
    result= Language.objects.annotate(no_books=Count('book')).values('id','name','no_books').order_by('name')
    return render(request, 'lanlist.html', {'result':result})
def addbookform(request):
    form=BookForm()
    return render(request,'addbookform.html',{'form':form})
def addbook(request):
    if request.method == "POST":  
       k=BookForm(data=request.POST)
       z=BookForm(request.POST)
       if Book.objects.filter(book_id=k['book_id'].value()).exists():
            messages.success(request,"book already exists")
       elif z.is_valid():
            if z.cleaned_data['total_copies']== z.cleaned_data['available_copies']:
              z.save()
              messages.success(request,"book added")
            else:
              messages.success(request,"book cannot be added ")
       else:
          messages.success(request,"invalid data")  
       form=BookForm()
       return render(request,'addbookform.html',{'form':form})
@login_required
def booklist(request):
    #result=Book.objects.all().order_by('-title','author')
    result=Book.objects.annotate(Count('borrower__student__roll_no',distinct=True)).values('id','book_id','title','author','summary','version','genre__name','language__name','total_copies','available_copies','borrower__student__roll_no__count').order_by('-title','author')
    p = Paginator(result,5)
    page_num=request.GET.get('page',1)
    p=p.page(page_num)
    return render(request, 'booklist.html', {'result':p})
def bookdetailform1(request):
    return render(request,'bookdetailform1.html')
def bookdetailform2(request):
    return render(request,'bookdetailform2.html')
def bookdetail1(request):
    if request.method == "POST" :
        if Book.objects.filter(genre__name=request.POST['genre']).exists():
           data=Book.objects.filter(genre__name=request.POST['genre']).annotate(Count('borrower__student__roll_no',distinct=True)).values('id','book_id','title','author','summary','version','genre__name','language__name','total_copies','available_copies','borrower__student__roll_no__count').order_by('-title','author')
           return render(request, 'booklist.html', {'result':data})
        else:
           messages.success(request,"Books not found")
           return render(request, 'booklist.html')
def bookdetail2(request):
    if request.method == "POST" :
        if Book.objects.filter(language__name=request.POST['language']).exists():
           data=Book.objects.filter(language__name=request.POST['language']).annotate(Count('borrower__student__roll_no',distinct=True)).values('id','book_id','title','author','summary','version','genre__name','language__name','total_copies','available_copies','borrower__student__roll_no__count').order_by('-title','author')
           print(data.values())
           return render(request, 'booklist.html', {'result':data})
        else:
           messages.success(request,"Books not found")
           return render(request, 'booklist.html')
def addborrowerform(request):
    return render(request,'addborrowerform.html')
def addborrower(request):
    if request.method == "POST" :
        k=request.POST['book_id']
        p=request.POST['roll_no']
        if Book.objects.filter(book_id=k).exists() and Student.objects.filter(roll_no=p).exists():
            obj = Book.objects.get(book_id=k)
            s=Student.objects.get(roll_no=p)
            if Borrower.objects.filter(book__book_id=k,student__roll_no=p).exists():
               messages.success(request,"already book taken")
            elif s.total_books_due < 7:
                messages.success(request,"book has been issued, You can collect book from library")
                a = Borrower()
                a.student = s
                a.book = obj
                a.issue_date = datetime.datetime.now()
                if obj.available_copies -1>=1:
                    obj.available_copies = obj.available_copies - 1
                    obj.save()
                    s.total_books_due=s.total_books_due+1
                    s.save()
                    a.save()
                else:
                    messages.success(request,"No available books to issue")
            else:
                messages.success(request,"you have exceeded limit.")
        else:
            messages.success(request,"invalid student or book")
        return render(request, 'addborrowerform.html')    
def updateborrowerform(request):
    return render(request,'updateborrowerform.html')
def updateborrower(request):
    if request.method == "POST" :
        k=request.POST['book_id']
        p=request.POST['roll_no']
        if Book.objects.filter(book_id=k).exists() and Student.objects.filter(roll_no=p).exists() and Borrower.objects.filter(student__roll_no=p,book__book_id=k).exists():
            obj = Book.objects.get(book_id=k)
            s=Student.objects.get(roll_no=p)
            s.total_books_due=s.total_books_due-1
            obj.available_copies=obj.available_copies+1
            s.save()
            obj.save()
            Borrower.objects.get(student=s,book=obj).delete()
            messages.success(request,"book successfully return")
        else:
            messages.warning(request,"borrower does not exist")
        return render(request, 'updateborrowerform.html')
@login_required
def borrowerlist(request):
    k=Borrower.objects.all().order_by('issue_date')
    p = Paginator(k,5)
    page_num=request.GET.get('page',1)
    p=p.page(page_num)
    return render(request, 'borrowerlist.html',{'result':p})
def borrowerdetailbyroll(request,parameter):
    p=parameter
    if Student.objects.filter(roll_no=p).exists():
        if Borrower.objects.filter(student__roll_no=p).exists():
            a=Borrower.objects.filter(student__roll_no=p)
            result=a
            context={'result':result,'p':p,}
            return render(request, 'borrowerlistp.html',context)
        else:
            result="borrower not found"
            context={'result':result,'p':p,}
            return render(request, 'resultp.html',context)
    else:
        result="borrower not found as student invalid"
        return render(request, 'result1.html',{'result':result})
def studentDetailbyroll(request,parameter):
    if Student.objects.filter(roll_no=parameter).exists():
       data=Student.objects.get(roll_no=parameter)
       context={'i':data,'p':parameter,}
       return render(request, 'studentDetailp.html',context)
    else:
        data="student not found"
        context={'result':data,'p':parameter,}
        return render(request, 'resultp.html',context)
def genrelistp(request,parameter):
    result=Genre.objects.all()
    context={'result':result,'p':parameter}
    return render(request, 'genrelistp.html',context)
def lanlistp(request,parameter):
    result=Language.objects.all()
    context={'result':result,'p':parameter}
    return render(request, 'lanlistp.html',context)
def bookdetailform1p(request,parameter):
    return render(request,'bookdetailform1p.html',{'p':parameter})
def bookdetailform2p(request,parameter):
    return render(request,'bookdetailform2p.html',{'p':parameter})
def bookdetail1p(request,parameter):
    if request.method == "POST" :
        if Book.objects.filter(genre__name=request.POST['genre']).exists():
           data=Book.objects.filter(genre__name=request.POST['genre'])
           context={'result':data,'p':parameter,}
           return render(request, 'bookdetailp.html',context)
        else:
           data="Books not found"
           context={'result':data,'p':parameter,}
           return render(request, 'resultp.html',context)
def bookdetail2p(request,parameter):
    if request.method == "POST" :
        if Book.objects.filter(language__name=request.POST['language']).exists():
           data=Book.objects.filter(language__name=request.POST['language'])
           context={'result':data,'p':parameter,}
           return render(request, 'bookdetailp.html',context)
        else:
           data="Books not found"
           context={'result':data,'p':parameter,}
           return render(request, 'resultp.html',context)
def home(request):
    return render(request,'home.html')
def ubookeditform(request,id):
    b=Book.objects.get(id=id)
    form=BookUpdateForm(instance=b)
    context={'form':form,'id':id}
    return render(request,'ubookeditform.html',context)
def ubookedit(request,id):
    b=Book.objects.get(id=id)
    k=BookUpdateForm(request.POST,instance=b)
    z=BookUpdateForm()
    if k.is_valid():
        k.save()
        messages.success(request,"updated successfully")
        return render(request,'ubookeditform.html',{'form':k,'id':id})
    else:
        messages.success(request,"book already exists")
        return render(request,'ubookeditform.html',{'form':z,'id':id})
def ubookdelete(request,id):
    b=Book.objects.get(id=id)
    b.delete()
    messages.success(request,"deleted successfully")
    p=Book.objects.annotate(Count('borrower__student__roll_no',distinct=True)).values('id','book_id','title','author','summary','version','genre__name','language__name','total_copies','available_copies','borrower__student__roll_no__count').order_by('-title','author')
    return render(request,'booklist.html',{'result':p})
def ustudentedit(request,id):
    if request.method=="POST":
        b=Student.objects.get(id=id)
        k=StudentForm(request.POST,instance=b)
        if k.is_valid():
            k.save()
            messages.success(request,"updated successfully")
            return render(request,'ustudenteditform.html',{'form':k,'id':id})
        else:
            messages.success(request,"student already exists")
            return render(request,'ustudenteditform.html',{'form':k,'id':id})   
def ustudentdelete(request,id):
    b=Student.objects.get(id=id)
    if b.total_books_due>=1:
        messages.success(request,"clear books to delete student")
        d=Student.objects.all()
    else:
        b.delete()
        d=Student.objects.all()
        messages.success(request,"deleted successfully")
    return render(request,'studentlist.html',{'result':d})
def ustudenteditform(request,id):
    p=Student.objects.get(id=id)
    form=StudentForm(instance=p)
    context={'form':form,'id':id}
    return render(request,'ustudenteditform.html',context)
def ugenredelete(request,id):
    b=Genre.objects.get(id=id)
    b.delete()
    messages.success(request,"deleted successfully")
    a=Genre.objects.annotate(no_books=Count('book')).values('id','name','no_books').order_by('name')
    return render(request,'genrelist.html',{'result':a})
def ulandelete(request,id):
    b=Language.objects.get(id=id)
    b.delete()
    messages.success(request,"deleted successfully")
    d=Language.objects.annotate(no_books=Count('book')).values('id','name','no_books').order_by('name')
    return render(request,'lanlist.html',{'result':d})
def uborrowerdelete(request,id):
    b=Borrower.objects.get(id=id)
    b.delete()
    s="deleted successfully"
    return render(request,'result.html',{'result':s})
def search1(request):
    if request.method=="POST":
        k=request.POST.get('get_value')
        if k=='roll_no':
            if request.method == "POST" :
                p=request.POST['value']
                if Student.objects.filter(roll_no=p).exists():
                    if Borrower.objects.filter(student__roll_no=p).exists():
                        a=Borrower.objects.filter(student__roll_no=p)
                        result=a
                        return render(request, 'borrowerlist.html',{'result':result})
                    else:
                        messages.error(request,"borrower not found")
                        return render(request, 'borrowerlist.html')
                else:
                    messages.success(request,"borrower not found as student invalid")
                    return render(request, 'borrowerlist.html')
        elif k=='book_id':
            if request.method == "POST" :
                p=request.POST['value']
                if Book.objects.filter(book_id=p).exists():
                    if Borrower.objects.filter(book__book_id=p).exists():
                        a=Borrower.objects.filter(book__book_id=p)
                        result=a
                        return render(request, 'borrowerlist.html',{'result':result})
                    else:
                        messages.error(request,"borrower not found")
                        return render(request, 'borrowerlist.html')
                else:
                    messages.error(request,"borrower not found as book invalid")
                    return render(request, 'borrowerlist.html')
def search3(request): 
    if request.method=="POST":
         k=request.POST.get('get_value')
         if k=='title':
            if Book.objects.filter(title=request.POST['value']).exists():
                data=Book.objects.filter(title=request.POST['value']).annotate(Count('borrower__student__roll_no',distinct=True)).values('id','book_id','title','author','summary','version','genre__name','language__name','total_copies','available_copies','borrower__student__roll_no__count').order_by('-title','author')
                return render(request, 'booklist.html', {'result':data})
            else:
                messages.success(request,"Books not found")
                return render(request, 'booklist.html')
            return render(request,'bookdetailform.html')
         elif k=='genre':
             if Book.objects.filter(genre__name=request.POST['value']).exists():
                data=Book.objects.filter(genre__name=request.POST['value']).annotate(Count('borrower__student__roll_no',distinct=True)).values('id','book_id','title','author','summary','version','genre__name','language__name','total_copies','available_copies','borrower__student__roll_no__count').order_by('-title','author')
                return render(request, 'booklist.html', {'result':data})
             else:
                messages.success(request,"Books not found")
                return render(request, 'booklist.html')
         elif k=='language':
             if Book.objects.filter(language__name=request.POST['value']).exists():
                data=Book.objects.filter(language__name=request.POST['value']).annotate(Count('borrower__student__roll_no',distinct=True)).values('id','book_id','title','author','summary','version','genre__name','language__name','total_copies','available_copies','borrower__student__roll_no__count').order_by('-title','author')
                return render(request, 'booklist.html', {'result':data})
             else:
                messages.success(request,"Books not found")
                return render(request, 'booklist.html')    
         elif k=='book_id':
             if Book.objects.filter(book_id=request.POST['value']).exists():
                data=Book.objects.filter(book_id=request.POST['value']).annotate(Count('borrower__student__roll_no',distinct=True)).values('id','book_id','title','author','summary','version','genre__name','language__name','total_copies','available_copies','borrower__student__roll_no__count').order_by('-title','author')
                return render(request, 'booklist.html', {'result':data})
             else:
                messages.success(request,"Books not found")
                return render(request, 'booklist.html') 
@login_required                
def totalborrowers(request):
    p=Student.objects.filter(total_books_due__gte=1).count()
    k="total students who took books:"+str(p)
    messages.success(request,k)
    return render(request,'home.html')
@login_required
def totalbookstaken(request):
    z=Student.objects.all().aggregate(Sum('total_books_due'))
    messages.success(request,str(z))
    return render(request,'home.html')
def borrowersearchform(request):
    return render(request,'borrowersearchform.html')
def borrowersearch(request):
    if request.method == "POST" :
        p=request.POST['book_id']
        q=request.POST['roll_no']
        if Borrower.objects.filter(book__book_id=p,student__roll_no=q).exists():
            a=Borrower.objects.filter(book__book_id=p,student__roll_no=q)
            return render(request, 'borrowerlist.html',{'result':a})
        else:
            messages.error(request,"borrower not found")
            return render(request, 'borrowerlist.html')
        
    
    




        

