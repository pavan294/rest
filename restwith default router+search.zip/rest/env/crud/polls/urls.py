from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .import views
from polls.views import EmployeeViewSet,EmployeeView,UserListView
router = DefaultRouter()
router.register(r'employee', views.EmployeeViewSet)
urlpatterns = [
    path('', include(router.urls)),
    path('Em',views.EmployeeView.as_view(), name='employee'),
    path('UserListView',views.UserListView.as_view(), name='UserListView'),
]
