'''
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
  
from polls.models import Employee
from polls.serializers import Employeeserializer
  
@csrf_exempt
def polls_list(request):
    """
    List all transformers, or create a new transformer
    """
    if request.method == 'GET':
        transformer =Employee.objects.all()
        serializer = Employeeserializer(transformer, many=True)
        return JsonResponse(serializer.data, safe=False)
  
    elif request.method == 'POST':
        data = JSONParser().parse(request)
        serializer =Employeeserializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data, status=201)
        return JsonResponse(serializer.errors, status=400)
  
@csrf_exempt
def polls_detail(request, pk):
    try:
        transformer = Employee.objects.get(pk=pk)
    except Transformer.DoesNotExist:
        return HttpResponse(status=404)
  
    if request.method == 'GET':
        serializer =Employeeserializer(transformer)
        return JsonResponse(serializer.data)
  
    elif request.method == 'PUT':
        data = JSONParser().parse(request)
        serializer = Employeeserializer(transformer, data=data)
  
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data)
        return JsonResponse(serializer.errors, status=400)
  
    elif request.method == 'DELETE':
        transformer.delete()
        return HttpResponse(status=204)
'''
from django.shortcuts import render
from django.http import JsonResponse
from rest_framework import serializers
from .models import Employee
from .serializers  import  Employeeserializer
from rest_framework.views import APIView
from rest_framework import viewsets
from django.views.generic import CreateView
from rest_framework.response import Response
from rest_framework import status,filters
from rest_framework.views import APIView
from rest_framework.renderers import JSONRenderer,TemplateHTMLRenderer,AdminRenderer
from rest_framework import generics
from rest_framework.decorators import action
from rest_framework.parsers import JSONParser
class EmployeeView(APIView):
    renderer_classes = [TemplateHTMLRenderer]
    parser_classes = [JSONParser]
    template_name = 'employee.html'
    serializer_class=Employeeserializer
    def get(self, request):
        a=Employeeserializer()
        return Response({'res':a})
def home(request):
    return render(request,'employee.html')


class UserListView(generics.ListAPIView):
    queryset = Employee.objects.all()
    serializer_class =Employeeserializer
    filter_backends = [filters.SearchFilter]
    search_fields = ['last_name','first_name']
class EmployeeViewSet(viewsets.ModelViewSet):
    serializer_class=Employeeserializer
    queryset=Employee.objects.all()
    lookup_field='pk'
    renderer_classes = [AdminRenderer]
    def list(self,request):
        a=Employee.objects.all()
        s=Employeeserializer(a,many=True)
        return Response(s.data,status=status.HTTP_201_CREATED)
    def create(self,request):
        s= Employeeserializer(data=request.data)
        if s.is_valid():
            s.save()
            return Response(s.data,status=status.HTTP_201_CREATED)
        else:
            return Response(s.errors, status=status.HTTP_400_BAD_REQUEST)
    def retrieve(self,request,pk):
        a=Employee.objects.get(id=pk)
        s=Employeeserializer(a)
        return Response(s.data,status=status.HTTP_200_OK)
    def update(self,request,pk):
        a=Employee.objects.get(id=pk)
        serializer=Employeeserializer(a,request.data)
        if serializer.is_valid():
           serializer.save()
           return Response(serializer.data,status=status.HTTP_201_CREATED)
        else:
           return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    def partial_update(self,request,pk):
        a=Employee.objects.get(id=pk)
        serializer=Employeeserializer(a,request.data,partial=True)
        if serializer.is_valid():
           serializer.save()
           return Response(serializer.data,status=status.HTTP_201_CREATED)
        else:
           return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    def delete(self,request,pk):
        b=Employee.objects.get(id=pk)
        b.delete()
        return Response(status=status.HTTP_404_NOT_FOUND)
    @action(detail=False)
    def yoga(self, request):
        a=Employee.objects.all()
        s=Employeeserializer(a,many=True)
        return Response(s.data,status=status.HTTP_201_CREATED)
            