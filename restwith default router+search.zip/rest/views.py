import functools
l=[1,2,3]
def add(*x):
    return sum(*x)
print(functools.reduce(add,l))
